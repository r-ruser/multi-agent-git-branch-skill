# multi-agent-git-branch skill

This package installs one reusable skill for Codex App, Claude Code, and Hermes Agent.

## What it does

It gives all three agents the same workflow for working on one repository safely:

- Codex App creates task files only.
- Claude Code implements on its own branch.
- Hermes Agent reviews Claude's patch on a review-only branch.
- Integration happens on `integrate/<TASK_ID>` before merging into `main`.

## Install on Windows for Codex App and Claude Code, plus WSL Hermes

Open PowerShell inside the extracted package directory and run:

```powershell
powershell -ExecutionPolicy Bypass -File .\multi-agent-git-branch\scripts\install-windows.ps1
```

This copies the skill to:

```text
%USERPROFILE%\.agents\skills\multi-agent-git-branch
%USERPROFILE%\.claude\skills\multi-agent-git-branch
~/.hermes/skills/multi-agent-git-branch  # inside WSL
```

If you want to skip Hermes:

```powershell
powershell -ExecutionPolicy Bypass -File .\multi-agent-git-branch\scripts\install-windows.ps1 -SkipHermes
```

## Install only inside WSL Hermes

From WSL:

```bash
bash multi-agent-git-branch/scripts/install-wsl-hermes.sh
```

## Test

Claude Code:

```text
/multi-agent-git-branch
```

Hermes:

```text
/skills list
/multi-agent-git-branch
```

Codex App:

Ask it:

```text
Use the multi-agent-git-branch skill to plan this task. Do not modify source code; create task files under .ai_bus/inbox only.
```

If Codex App does not show the new skill, restart the app.

## First project setup

In the target repository:

```powershell
powershell -ExecutionPolicy Bypass -File "$env:USERPROFILE\.claude\skills\multi-agent-git-branch\scripts\init-multi-agent-bus.ps1"
```

Then create a task:

```powershell
powershell -ExecutionPolicy Bypass -File "$env:USERPROFILE\.claude\skills\multi-agent-git-branch\scripts\new-agent-task.ps1" -TaskId "20260516_task001" -Assignee claude -Type code_fix -Priority high
```
