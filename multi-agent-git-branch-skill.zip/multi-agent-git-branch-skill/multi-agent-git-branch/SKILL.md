---
name: multi-agent-git-branch
description: Coordinate Codex App, Claude Code, and Hermes Agent on one project using Git branch isolation, task files, review-only branches, patches, and integration branches. Use when planning, dispatching, reviewing, or merging multi-agent coding/research tasks.
version: 1.0.0
---

# Multi-agent Git branch workflow

Use this skill whenever a task involves more than one agent, especially Codex App, Claude Code, and Hermes Agent working on the same repository.

The objective is to prevent tool collisions. Each agent works in its own Git branch. No agent edits `main` directly. Codex usually plans tasks, Claude usually implements code changes, Hermes usually reviews the diff, and an integration branch merges the accepted work.

## Roles

- Codex App: task manager and final integrator. It creates task files under `.ai_bus/inbox/` and later reads `.ai_bus/done/`, `.ai_bus/reviews/`, and Git diffs to integrate work.
- Claude Code: implementation worker. It modifies only files explicitly allowed by the task file.
- Hermes Agent: review worker by default. It reviews Claude's patch and task file, then writes a review report. Hermes may fix only when a separate `agent/hermes-fix/<TASK_ID>` branch is explicitly created.

## Non-negotiable rules

1. Never modify `main` directly.
2. Before creating a branch, check `git status --short`. If the working tree is not clean, stop and ask whether to commit, stash, or discard.
3. Do not let two agents modify the same source file in parallel.
4. Do not modify raw data, downloaded public database files, or immutable input files unless the task explicitly says so.
5. Every implementation must include a written summary explaining what changed, why the previous version failed, and how to diagnose the same problem next time.
6. Review-only branches must not modify source code. They may create files under `.ai_bus/reviews/` only.
7. Final merge happens only from `integrate/<TASK_ID>` into `main` after review.

## Standard directories

Create these directories at the repository root when missing:

```text
.ai_bus/
  inbox/      task files created by Codex
  done/       final worker summaries
  logs/       command logs
  patches/    exported diffs for review
  reviews/    Hermes review reports
  claims/     optional lock files
```

## Branch naming

Use this branch scheme:

```text
agent/codex/<TASK_ID>
agent/claude/<TASK_ID>
agent/hermes-review/<TASK_ID>
agent/hermes-fix/<TASK_ID>
integrate/<TASK_ID>
```

## Task file standard

Every task file must be Markdown and must include:

```text
# TASK_ID:
# ASSIGNEE: claude | hermes | codex
# TYPE: code_fix | review_only | method_check | refactor | integration
# PRIORITY: low | medium | high

## Background

## Task

## Files allowed to modify

## Files forbidden to modify

## Completion criteria
```

## Full workflow

### 1. Plan with Codex

Create a Codex planning branch from `main`:

```bash
git switch main
git status --short
git switch -c agent/codex/<TASK_ID>
```

Codex should create task files only under `.ai_bus/inbox/`, then commit them:

```bash
git add .ai_bus/inbox
git commit -m "plan: add task specs for <TASK_ID>"
git switch main
git merge --no-ff agent/codex/<TASK_ID> -m "merge Codex task plan for <TASK_ID>"
```

### 2. Implement with Claude

Create Claude implementation branch from `main`:

```bash
git switch main
git status --short
git switch -c agent/claude/<TASK_ID>
```

Claude reads the task file and edits only the allowed files. After editing:

```bash
git diff
git status --short
git add -A
git commit -m "claude: complete <TASK_ID>"
```

### 3. Export Claude diff for Hermes

Return to `main` and export the Claude patch:

```bash
git switch main
git diff main...agent/claude/<TASK_ID> > .ai_bus/patches/<TASK_ID>_claude.diff
git add .ai_bus/patches/<TASK_ID>_claude.diff
git commit -m "chore: add Claude diff for Hermes review <TASK_ID>"
```

### 4. Review with Hermes

Create a review-only branch from `main`:

```bash
git switch main
git status --short
git switch -c agent/hermes-review/<TASK_ID>
```

Hermes reads `.ai_bus/patches/<TASK_ID>_claude.diff` and the relevant task file, then writes `.ai_bus/reviews/<TASK_ID>_hermes_review.md`.

The review must answer:

1. Does the patch satisfy the task?
2. Did it modify forbidden files?
3. Are there code, path, dependency, data-cleaning, or statistical logic problems?
4. Should the implementation be merged?
5. If not, what exactly needs to be fixed?

Commit the review:

```bash
git add .ai_bus/reviews/<TASK_ID>_hermes_review.md
git commit -m "hermes: review <TASK_ID>"
```

### 5. Optional Hermes fix

Only if the review says the implementation should not be merged, create a fix branch from Claude's branch:

```bash
git switch agent/claude/<TASK_ID>
git switch -c agent/hermes-fix/<TASK_ID>
```

Hermes may then edit only files named in the review. Commit fixes:

```bash
git add -A
git commit -m "hermes: fix issues identified in <TASK_ID> review"
```

### 6. Integrate

If no Hermes fix was needed:

```bash
git switch main
git switch -c integrate/<TASK_ID>
git merge --no-ff agent/claude/<TASK_ID> -m "merge Claude implementation <TASK_ID>"
git merge --no-ff agent/hermes-review/<TASK_ID> -m "merge Hermes review <TASK_ID>"
```

If Hermes fix was needed:

```bash
git switch main
git switch -c integrate/<TASK_ID>
git merge --no-ff agent/hermes-fix/<TASK_ID> -m "merge Hermes-fixed implementation <TASK_ID>"
git merge --no-ff agent/hermes-review/<TASK_ID> -m "merge Hermes review <TASK_ID>"
```

Then validate and merge into `main`:

```bash
git status --short
git diff main...integrate/<TASK_ID>
# run project-specific validation commands here
git switch main
git merge --no-ff integrate/<TASK_ID> -m "final merge <TASK_ID> after multi-agent review"
```

## Output requirement for every agent

At the end of a task, write or report:

```text
TASK_ID:
Branch:
Files changed:
What was changed:
Why the previous version was wrong:
How to check this next time:
Validation commands run:
Remaining risks:
Merge recommendation:
```

## Data and manuscript projects

For epidemiology, biostatistics, manuscript, or database projects, add these checks:

- Do not change raw data paths unless asked.
- Preserve reproducibility by reporting package versions and R/Python versions when relevant.
- For model changes, identify the estimand, exposure, outcome, covariates, time window, and exclusion rules.
- For code errors, explain the immediate error and the upstream data-structure cause.
- For manuscript text, do not invent references, journal rules, variables, or results.
