param(
    [Parameter(Mandatory=$true)]
    [string]$TaskId,

    [ValidateSet("claude", "hermes", "codex")]
    [string]$Assignee = "claude",

    [ValidateSet("code_fix", "review_only", "method_check", "refactor", "integration")]
    [string]$Type = "code_fix",

    [ValidateSet("low", "medium", "high")]
    [string]$Priority = "medium"
)

$Inbox = ".ai_bus\inbox"
if (-not (Test-Path $Inbox)) {
    New-Item -ItemType Directory -Path $Inbox -Force | Out-Null
}

$File = Join-Path $Inbox "$TaskId`_$Assignee.md"

@"
# TASK_ID: $TaskId
# ASSIGNEE: $Assignee
# TYPE: $Type
# PRIORITY: $Priority

## Background

Write the current problem, error message, and relevant context here.

## Task

1. Read this task file first.
2. Modify only files explicitly allowed below.
3. Do not modify raw data or unrelated files.
4. At the end, explain what changed, why the previous version was wrong, and how to check this next time.

## Files allowed to modify

- TODO

## Files forbidden to modify

- raw_data/
- data_original/
- TODO

## Completion criteria

- TODO
"@ | Set-Content $File -Encoding UTF8

Write-Host "Created task file: $File"
