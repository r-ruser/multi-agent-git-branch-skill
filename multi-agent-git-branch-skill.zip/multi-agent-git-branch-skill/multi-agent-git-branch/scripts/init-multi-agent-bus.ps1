param(
    [string]$ProjectRoot = (Get-Location).Path
)

Set-Location $ProjectRoot

$dirs = @(
    ".ai_bus",
    ".ai_bus\inbox",
    ".ai_bus\done",
    ".ai_bus\logs",
    ".ai_bus\patches",
    ".ai_bus\reviews",
    ".ai_bus\claims",
    "scripts"
)

foreach ($dir in $dirs) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir | Out-Null
    }
}

if (-not (Test-Path ".git")) {
    git init
    git config core.autocrlf false
    git add .
    git commit -m "baseline before multi-agent workflow"
    git branch -M main
} else {
    git status --short
}

Write-Host "Initialized .ai_bus and Git workflow directories at $ProjectRoot"
