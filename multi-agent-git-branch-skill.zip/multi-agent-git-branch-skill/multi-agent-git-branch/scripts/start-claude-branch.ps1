param(
    [Parameter(Mandatory=$true)]
    [string]$TaskId
)

$dirty = git status --short
if ($dirty) {
    Write-Error "Working tree is not clean. Commit, stash, or discard changes before creating Claude branch."
    git status --short
    exit 1
}

git switch main
git switch -c "agent/claude/$TaskId"
Write-Host "Now in agent/claude/$TaskId. Run Claude against .ai_bus/inbox/$TaskId`_claude.md."
