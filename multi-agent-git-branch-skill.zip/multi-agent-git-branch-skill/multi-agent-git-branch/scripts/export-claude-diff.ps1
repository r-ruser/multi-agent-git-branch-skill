param(
    [Parameter(Mandatory=$true)]
    [string]$TaskId
)

git switch main
$PatchDir = ".ai_bus\patches"
if (-not (Test-Path $PatchDir)) {
    New-Item -ItemType Directory -Path $PatchDir -Force | Out-Null
}

$PatchFile = ".ai_bus\patches\$TaskId`_claude.diff"
git diff "main...agent/claude/$TaskId" > $PatchFile

git add $PatchFile
git commit -m "chore: add Claude diff for Hermes review $TaskId"
Write-Host "Exported Claude diff to $PatchFile"
