param(
    [Parameter(Mandatory=$true)]
    [string]$TaskId,

    [string]$ProjectRoot = (Get-Location).Path
)

function Convert-ToWslPath([string]$Path) {
    $full = (Resolve-Path $Path).Path
    $drive = $full.Substring(0,1).ToLower()
    $rest = $full.Substring(2).Replace('\','/')
    return "/mnt/$drive$rest"
}

$PatchFile = ".ai_bus\patches\$TaskId`_claude.diff"
$TaskFile = ".ai_bus\inbox\$TaskId`_claude.md"
$ReviewFile = ".ai_bus\reviews\$TaskId`_hermes_review.md"

if (-not (Test-Path $PatchFile)) {
    Write-Error "Patch file not found: $PatchFile"
    exit 1
}
if (-not (Test-Path $TaskFile)) {
    Write-Error "Task file not found: $TaskFile"
    exit 1
}

$ProjectWsl = Convert-ToWslPath $ProjectRoot

$cmd = @"
cd '$ProjectWsl' && hermes -z 'Use the multi-agent-git-branch skill. Review only. Do not modify source code. Read .ai_bus/patches/$TaskId`_claude.diff and .ai_bus/inbox/$TaskId`_claude.md. Write a structured review covering task compliance, forbidden-file edits, raw-data edits, code logic, path/dependency risks, statistical or analytical risks if relevant, and merge recommendation.' > .ai_bus/reviews/$TaskId`_hermes_review.md
"@

wsl bash -lc $cmd
Write-Host "Hermes review written to $ReviewFile"
