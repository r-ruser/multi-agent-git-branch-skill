param(
    [Parameter(Mandatory=$true)]
    [string]$TaskId
)

$dirty = git status --short
if ($dirty) {
    Write-Error "Working tree is not clean. Commit, stash, or discard changes before creating Hermes review branch."
    git status --short
    exit 1
}

git switch main
git switch -c "agent/hermes-review/$TaskId"
Write-Host "Now in agent/hermes-review/$TaskId. Run Hermes review only."
