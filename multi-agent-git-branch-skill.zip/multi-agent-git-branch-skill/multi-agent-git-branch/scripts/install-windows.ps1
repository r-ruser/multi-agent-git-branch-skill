param(
    [string]$SkillRoot = (Split-Path -Parent $PSScriptRoot),
    [switch]$SkipHermes
)

$SkillName = "multi-agent-git-branch"
$Source = $SkillRoot
if ((Split-Path -Leaf $Source) -ne $SkillName) {
    $candidate = Join-Path $SkillRoot $SkillName
    if (Test-Path $candidate) { $Source = $candidate }
}

if (-not (Test-Path (Join-Path $Source "SKILL.md"))) {
    Write-Error "Cannot find SKILL.md under $Source"
    exit 1
}

$CodexDest = Join-Path $env:USERPROFILE ".agents\skills\$SkillName"
$ClaudeDest = Join-Path $env:USERPROFILE ".claude\skills\$SkillName"

New-Item -ItemType Directory -Path (Split-Path $CodexDest) -Force | Out-Null
New-Item -ItemType Directory -Path (Split-Path $ClaudeDest) -Force | Out-Null

if (Test-Path $CodexDest) { Remove-Item $CodexDest -Recurse -Force }
if (Test-Path $ClaudeDest) { Remove-Item $ClaudeDest -Recurse -Force }

Copy-Item $Source $CodexDest -Recurse
Copy-Item $Source $ClaudeDest -Recurse

Write-Host "Installed for Codex App: $CodexDest"
Write-Host "Installed for Claude Code: $ClaudeDest"

if (-not $SkipHermes) {
    function Convert-ToWslPath([string]$Path) {
        $full = (Resolve-Path $Path).Path
        $drive = $full.Substring(0,1).ToLower()
        $rest = $full.Substring(2).Replace('\','/')
        return "/mnt/$drive$rest"
    }

    $SourceWsl = Convert-ToWslPath $Source
    $cmd = "mkdir -p ~/.hermes/skills && rm -rf ~/.hermes/skills/$SkillName && cp -r '$SourceWsl' ~/.hermes/skills/$SkillName && echo Installed for Hermes: ~/.hermes/skills/$SkillName"
    wsl bash -lc $cmd
}

Write-Host "Done. Restart Codex App if it does not show the skill. Claude Code usually hot-loads skills; restart if needed."
