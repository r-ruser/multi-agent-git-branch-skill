#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
SKILL_NAME="multi-agent-git-branch"
DEST="$HOME/.hermes/skills/$SKILL_NAME"

mkdir -p "$HOME/.hermes/skills"
rm -rf "$DEST"
cp -R "$SKILL_ROOT" "$DEST"

echo "Installed for Hermes: $DEST"
echo "Test in Hermes with: /skills list"
