param(
    [Parameter(Mandatory=$true)]
    [string]$TaskId,

    [switch]$UseHermesFix
)

$dirty = git status --short
if ($dirty) {
    Write-Error "Working tree is not clean. Commit, stash, or discard changes before integration."
    git status --short
    exit 1
}

git switch main
git switch -c "integrate/$TaskId"

if ($UseHermesFix) {
    git merge --no-ff "agent/hermes-fix/$TaskId" -m "merge Hermes-fixed implementation $TaskId"
} else {
    git merge --no-ff "agent/claude/$TaskId" -m "merge Claude implementation $TaskId"
}

git merge --no-ff "agent/hermes-review/$TaskId" -m "merge Hermes review $TaskId"

git status --short
git diff "main...integrate/$TaskId"
Write-Host "Integration branch ready: integrate/$TaskId"
Write-Host "Run validation. If clean, merge into main with:"
Write-Host "git switch main"
Write-Host "git merge --no-ff integrate/$TaskId -m 'final merge $TaskId after multi-agent review'"
