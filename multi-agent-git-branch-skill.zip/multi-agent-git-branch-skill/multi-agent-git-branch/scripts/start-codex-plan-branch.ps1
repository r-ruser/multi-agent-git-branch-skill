param(
    [Parameter(Mandatory=$true)]
    [string]$TaskId
)

$dirty = git status --short
if ($dirty) {
    Write-Error "Working tree is not clean. Commit, stash, or discard changes before creating a Codex planning branch."
    git status --short
    exit 1
}

git switch main
git switch -c "agent/codex/$TaskId"
Write-Host "Now in agent/codex/$TaskId. Ask Codex App to create task files under .ai_bus/inbox only."
