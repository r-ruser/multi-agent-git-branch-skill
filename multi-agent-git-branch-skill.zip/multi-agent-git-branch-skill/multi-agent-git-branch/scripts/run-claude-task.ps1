param(
    [Parameter(Mandatory=$true)]
    [string]$TaskId
)

$TaskFile = ".ai_bus\inbox\$TaskId`_claude.md"
$LogFile = ".ai_bus\logs\$TaskId`_claude.log"
$DoneFile = ".ai_bus\done\$TaskId`_claude.result.md"

if (-not (Test-Path $TaskFile)) {
    Write-Error "Task file not found: $TaskFile"
    exit 1
}

$prompt = @"
Use the multi-agent-git-branch workflow.
Read $TaskFile and execute it strictly.
Only modify files listed as allowed in the task file.
Do not modify raw data.
At the end, report:
TASK_ID, branch, files changed, what changed, why the previous version was wrong, how to check this next time, validation commands run, remaining risks, merge recommendation.
"@

claude -p $prompt --allowedTools "Read,Edit,Bash" --output-format text *> $LogFile
Get-Content $LogFile -Raw | Set-Content $DoneFile -Encoding UTF8
Write-Host "Claude log: $LogFile"
Write-Host "Claude result: $DoneFile"
