# Branch-isolated multi-agent workflow reference

## Minimal task lifecycle

1. `agent/codex/<TASK_ID>`: create task files only.
2. `agent/claude/<TASK_ID>`: implement code changes.
3. `main`: store exported Claude diff under `.ai_bus/patches/`.
4. `agent/hermes-review/<TASK_ID>`: review patch only.
5. `agent/hermes-fix/<TASK_ID>`: optional fix branch, based on Claude branch.
6. `integrate/<TASK_ID>`: merge accepted work and review.
7. `main`: final merge after validation.

## What each branch may modify

| Branch | May modify | Must not modify |
|---|---|---|
| `agent/codex/<TASK_ID>` | `.ai_bus/inbox/` | source code, raw data |
| `agent/claude/<TASK_ID>` | files allowed by task | forbidden files, raw data |
| `agent/hermes-review/<TASK_ID>` | `.ai_bus/reviews/` | source code |
| `agent/hermes-fix/<TASK_ID>` | files named in review | unrelated files |
| `integrate/<TASK_ID>` | conflict resolution only | unrelated refactors |

## Preflight checks

```bash
git switch main
git status --short
git log --oneline -5
```

Proceed only if `git status --short` is empty.

## Standard validation order

1. Inspect diff.
2. Run minimal syntax checks.
3. Run unit or module-level tests.
4. Run full analysis only after module-level checks pass.
5. Commit only after outputs are reviewed.

## Conflict handling

If a merge conflict occurs:

1. Stop automatic work.
2. Run `git status`.
3. Open only conflict-marked files.
4. Resolve by preserving task intent and project conventions.
5. Run validation before committing the merge.

Never resolve conflicts by wholesale accepting one agent's version unless the task explicitly says that version is authoritative.
