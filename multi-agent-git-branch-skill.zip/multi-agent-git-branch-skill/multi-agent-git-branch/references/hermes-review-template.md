# Hermes review template

## Review target

- TASK_ID:
- Patch file:
- Task file:
- Review branch:

## Compliance check

- Satisfies task: yes/no/unclear
- Modified forbidden files: yes/no
- Raw data touched: yes/no
- Branch discipline followed: yes/no

## Code logic review

- Immediate correctness:
- Edge cases:
- Path and OS compatibility:
- Dependency risks:
- Reproducibility risks:

## Statistical or analytical review

- Exposure definition:
- Outcome definition:
- Time window:
- Covariate handling:
- Missingness handling:
- Model specification:
- Sensitivity checks needed:

## Recommendation

Choose one:

- Merge as is.
- Merge after minor documentation changes.
- Do not merge; fix required.

## Required fixes

List exact files and exact reasons.
