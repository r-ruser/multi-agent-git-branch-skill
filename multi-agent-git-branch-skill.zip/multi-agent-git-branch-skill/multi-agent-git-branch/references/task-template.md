# TASK_ID: YYYYMMDD_task001
# ASSIGNEE: claude
# TYPE: code_fix
# PRIORITY: high

## Background

Describe the problem, current error message, relevant files, and expected behavior.

## Task

1. Read the files listed below.
2. Identify the immediate error and the upstream cause.
3. Modify only allowed files.
4. Preserve existing data paths unless the task explicitly requires path changes.
5. Add or update validation commands when appropriate.

## Files allowed to modify

- path/to/file.R

## Files forbidden to modify

- raw_data/
- data_original/
- any file not listed above

## Completion criteria

- The script runs past the failing step.
- The diff is limited to allowed files.
- A summary is written with: what changed, why it failed, how to check next time, validation commands.
